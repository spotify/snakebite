VERSION = "2.2.4"


def version():
    return VERSION
