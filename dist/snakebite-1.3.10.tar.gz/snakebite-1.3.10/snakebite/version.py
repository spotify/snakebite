VERSION = "1.3.10"


def version():
    return VERSION
