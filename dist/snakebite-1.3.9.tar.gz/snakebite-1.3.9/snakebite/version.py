VERSION = "1.3.9"


def version():
    return VERSION
