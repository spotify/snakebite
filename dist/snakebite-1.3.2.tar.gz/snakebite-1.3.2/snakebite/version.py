VERSION = "1.3.2"


def version():
    return VERSION
