VERSION = "2.3.2"


def version():
    return VERSION
