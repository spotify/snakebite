VERSION = "2.2.0"


def version():
    return VERSION
