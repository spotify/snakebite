VERSION = "2.0.1"


def version():
    return VERSION
