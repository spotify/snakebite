VERSION = "2.3.5"


def version():
    return VERSION
