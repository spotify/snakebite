VERSION = "2.2.1"


def version():
    return VERSION
