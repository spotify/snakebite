VERSION = "2.4.6"


def version():
    return VERSION
