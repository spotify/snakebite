VERSION = "2.4.5"


def version():
    return VERSION
