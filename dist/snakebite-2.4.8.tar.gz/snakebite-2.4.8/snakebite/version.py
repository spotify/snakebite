VERSION = "2.4.8"


def version():
    return VERSION
