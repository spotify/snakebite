VERSION = "2.4.1"


def version():
    return VERSION
