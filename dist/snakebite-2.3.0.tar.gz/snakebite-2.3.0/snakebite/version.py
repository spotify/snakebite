VERSION = "2.3.0"


def version():
    return VERSION
