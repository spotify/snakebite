VERSION = "2.1.1"


def version():
    return VERSION
