VERSION = "2.2.5"


def version():
    return VERSION
