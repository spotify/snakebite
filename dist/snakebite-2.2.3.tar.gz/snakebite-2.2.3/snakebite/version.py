VERSION = "2.2.3"


def version():
    return VERSION
