VERSION = "2.4.3"


def version():
    return VERSION
