VERSION = "2.3.4"


def version():
    return VERSION
