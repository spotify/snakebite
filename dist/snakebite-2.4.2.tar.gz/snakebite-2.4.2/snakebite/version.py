VERSION = "2.4.2"


def version():
    return VERSION
