VERSION = "2.4.4"


def version():
    return VERSION
