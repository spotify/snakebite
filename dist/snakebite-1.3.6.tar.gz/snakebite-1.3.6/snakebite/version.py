VERSION = "1.3.6"


def version():
    return VERSION
